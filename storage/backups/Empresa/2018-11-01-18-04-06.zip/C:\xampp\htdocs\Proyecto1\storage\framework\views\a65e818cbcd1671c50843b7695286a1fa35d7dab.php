<?php ?>





<?php $__env->startSection('headder'); ?>


   
   <nav aria-label="breadcrumb ">
 
  <ol class="breadcrumb arr-right bg-dark ">
 
    <li class="breadcrumb-item "><a href="#" class="text-light">Inicio</a></li>
 
    <li class="breadcrumb-item text-light" aria-current="page"><a href="<?php echo e(route('profile')); ?>" class="text-light">Mi perfil</a></li>

  <li class="breadcrumb-item text-light active" aria-current="page">Cambiar Contraseña</li>

  </ol></nav>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenido'); ?>

<style type="text/css"></style>

 <div class="container-fluid">
  <div class="row">

<div class="col-md-3 responsive">
</div>
<div class="col-md-5 responsive">
<div class="card">
  <h5 class="card-header">Cambiar Contraseña</h5>
  <div class="card-body">

  



<div class="panel-body">
<?php if(session('error')): ?>
</div>
<div class="alert alert-danger">
<?php echo e(session('error')); ?>

</div>
<?php endif; ?>
<?php if(session('success')): ?>
<div class="alert alert-success">
<?php echo e(session('success')); ?>

</div>

<?php endif; ?>






<form class="form-horizontal " method="POST" action="<?php echo e(route('changePassword')); ?>">
<?php echo e(csrf_field()); ?>



           

 <label class="control-label">Clave Actual :</label>
<div class="input-group mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text"><i class="fa fa-expeditedssl"></i></span>
  </div>
  <input class="form-control form-control<?php echo e($errors->has('current-password') ? ' is-invalid' : ''); ?> " type="password" name="current-password" placeholder="ingrese nombre Usuario" maxlength="128" value="<?php echo e(old('current-password')); ?>" required>
      <?php if($errors->has('current-password')): ?>
                                    <div class="invalid-feedback">
                                        <strong><?php echo e($errors->first('current-password')); ?></strong>
                                    </div>
                                <?php endif; ?>
</div>


<label class="control-label">Contraseña nueva:</label>
<div class="input-group mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text"><i class="fa  fa-expeditedssl"></i></span>
  </div>
  <input class="form-control form-control<?php echo e($errors->has('new-password') ? ' is-invalid' : ''); ?> " type="password" name="new-password" placeholder="ingrese nombre Usuario" maxlength="128" value="" required>
      <?php if($errors->has('new-password')): ?>
                                    <div class="invalid-feedback">
                                        <strong><?php echo e($errors->first('new-password')); ?></strong>
                                    </div>
                                <?php endif; ?>
</div>


<label class="control-label">Confirmar Contraseña:</label>
<div class="input-group mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text"><i class="fa fa fa-expeditedssl fa-fw"></i></span>
  </div>
  <input class="form-control form-control" type="password" name="new-password_confirmation" placeholder="ingrese confirmación de contraseña" maxlength="128" value="" required>
    
</div>


<button type="submit" class="btn btn-primary">Aceptar</form>

  </div>
</div>



</div>
<div class="col-md-4 responsive">
</div>
</div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('administrador.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>