<!DOCTYPE html>
<html lang="en">
  <head>

     <title>PLATAFORMA WEB</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/main.css')); ?>">
    <!-- Font-icon css-->
  <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="shortcut icon" href="<?php echo e(asset('img/mujers.png')); ?>">
<style>
 
.arr-right .breadcrumb-item+.breadcrumb-item::before {
 
  content: "›";
 
  vertical-align:top;
 
  color: #408080;
 
  font-size:35px;
 
  line-height:18px;
 
}
 
</style>
      



  </head>
  <body class="app sidebar-mini rtl">
    <!-- Navbar-->
    <header class="app-header"><a class="app-header__logo" href="index.html">Plataforma web</a>
      <!-- Sidebar toggle button--><a class="app-sidebar__toggle" href="#" data-toggle="sidebar" aria-label="Hide Sidebar"></a>
      <!-- Navbar Right Menu-->
      <ul class="app-nav">
        <li class="app-search">
       
        </li>
        <!--Notification Menu-->
        <li class="dropdown">


        </li>

        <!-- User Menu-->
        <li class="dropdown"><a class="app-nav__item" href="#" data-toggle="dropdown" aria-label="Open Profile Menu"><i class="fa fa-user fa-lg"></i></a>
          <ul class="dropdown-menu settings-menu dropdown-menu-right">
            <li><a class="dropdown-item" href="<?php echo e(route('profile')); ?>"><i class="fa fa-user fa-lg"></i> Mi perfil</a></li>
            <li><a class="dropdown-item" href="<?php echo e(route('logout')); ?>"  onclick="event.preventDefault();
              document.getElementById('logout-form').submit();"><i class="fa fa-sign-out fa-lg"></i>Salir</a>
                      <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo e(csrf_field()); ?>

                      </form></li>
          </ul>
        </li>
      </ul>
    </header>
    <!-- Sidebar menu-->
    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
    <aside class="app-sidebar">


  
      <ul class="app-menu">
     
        <?php if (\Entrust::can(['user-update','user-delete','user-list','user-create','role-update','role-delete','role-list','role-create'])) : ?>
        <li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-folder"></i><span class="app-menu__label">Usuarios</span>
          <i class="treeview-indicator fa fa-angle-right"></i></a>
             <?php endif; // Entrust::can ?>


          <ul class="treeview-menu">
         <?php if (\Entrust::can(['user-update','user-delete','user-list','user-create'])) : ?>
            <li><a class="treeview-item" href="<?php echo e(route('users.index')); ?>"><i class="icon fa fa-user"></i> Usuarios</a></li>
     <?php endif; // Entrust::can ?>


<?php if (\Entrust::can(['role-update','role-delete','role-list','role-create'])) : ?>
            <li><a class="treeview-item" href="<?php echo e(route('roles.index')); ?>" target="_blank" rel="noopener"><i class="icon fa fa-cog""></i>Roles</a></li>
          <?php endif; // Entrust::can ?>


          </ul>
        </li>


      <?php if (\Entrust::can(['logs-list'])) : ?>
        <li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-laptop"></i><span class="app-menu__label">Logs</span>
          <i class="treeview-indicator fa fa-angle-right"></i></a>
             <?php endif; // Entrust::can ?>


          <ul class="treeview-menu">
       <?php if (\Entrust::can(['logs-list'])) : ?>
            <li><a class="treeview-item" href="<?php echo e(route('logs.logslist')); ?>"><i class="icon fa fa fa-arrow-circle-o-right"></i>Log Usuarios</a></li>
      <?php endif; // Entrust::can ?>



            <li><a class="treeview-item" href="<?php echo e(route('log-viewer::logs.list')); ?>" target="_blank" rel="noopener"><i class="icon fa fa fa-user"></i>Logs sistema</a></li>
        


          </ul>
        </li>



     
      </ul>
    </aside>
    <main class="app-content" style="background: white">
  
           <?php echo $__env->yieldContent('headder'); ?>
     
        <!-- Main content -->
       

          <?php echo $__env->yieldContent('contenido'); ?>
    </main>


      <!-- Essential javascripts for application to work-->
    <script src="<?php echo e(asset('js/jquery-3.2.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/main.js')); ?>"></script>
    <!-- The javascript plugin to display page loading on top-->
    <script src="<?php echo e(asset('js/plugins/pace.min.js')); ?>"></script>
    <!-- Page specific javascripts-->
    <script type="<?php echo e(asset('text/javascript')); ?>" src="js/plugins/chart.js"></script>



  </body>
</html>