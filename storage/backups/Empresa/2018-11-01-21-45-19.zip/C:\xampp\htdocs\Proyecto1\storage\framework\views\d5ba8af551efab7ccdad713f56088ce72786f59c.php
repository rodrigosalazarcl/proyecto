    <?php ?>





<?php $__env->startSection('headder'); ?>


     <ol class="breadcrumb">
  <li><a><i class="fa fa-dashboard"></i> Inicio</a></li>
  <li><a ><i class="fa fa-user"></i>Información de mi perfil</a></li>

</ol>
   

<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenido'); ?>

<style type="text/css">
  
    .read{ background: white !important;

     }


.blue{

    border-style: 1px; solid;
  font-size: 15px;
}
.green{color: green;}
label{
  text-align:left !important;
  font-size: 12px !important;
  font-weight: 200px !important;

}


.roles{background:#00a9a5 !important;color: white !important;
 border:none;
        border-width:0 !important;
        text-align: center !important;
}
</style>





  <div class="row">



  <div class="col-sm-2">
    
  </div>



  <div class="col-sm-7 blue" style="background:rgb(7, 90, 79);">
 <div class="well form-horizontal">
  <div class="well well-lg"  style="background:rgb(7, 90, 79);"><h4 style="font-family:verdana; color:white;">Información de perfil de Usuario</h4></div>
<div class="row">

    <div class="col-sm-4">
         <div class="form-group">
                         <?php if(Auth::user()->gender==='h'): ?>
                     <img  style="height:180px;width:200px; display:block;margin:auto;" src="<?php echo e(asset('img/hombre1.png')); ?>" class="img-circle img-responsive" alt="User Image">
                  <?php endif; ?>
                  <?php if(Auth::user()->gender==='m'): ?>
                     <img  style="height:180px;width:200px; display:block;margin:auto;" src="<?php echo e(asset('img/mujer1.jpg')); ?>" class="img-circle img-responsive" alt="User Image">
                  <?php endif; ?>     
      </div>
    </div>
      <div class="col-sm-4" align="right">
<div class="btn-group" ALIGN="RIGHT">
  <button type="button" class="btn label-warning dropdown-toggle fa fa-cog" data-toggle="dropdown" aria-expanded="false">
   Configuración <span class="caret"></span>
  </button>
  <ul class="dropdown-menu" role="menu">
    <li><a href="<?php echo e(route('logs.mylogs')); ?>">Ver sesiones Iniciadas</a></li>
    <li><a href="<?php echo e(route('changePassword')); ?>">Cambiar Contraseña</a></li>

  </ul>
</div>
</div>
                            </div>

                      <fieldset>
                        <div>
                         <div class="form-group">
                            <label class="col-md-4 control-label">NOMBRE USUARIO:</label>
                            <div class="col-md-8 inputGroupContainer">
                               <div class="input-group"><span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span><input id="NameUser" name="NameUser" class="read form-control" value="<?php echo e(Auth::user()->name); ?>" type="text" readonly></div>

                            </div>
                         </div>
                         <div class="form-group">
                            <label class="col-md-4 control-label">NOMBRES DEL USUARIO:</label>
                            <div class="col-md-8 inputGroupContainer">
                               <div class="input-group"><span class="input-group-addon"><i class="glyphicon glyphicon-star"></i></span><input id="firstname" name="firstname" class="read form-control" required="true" value="<?php echo e(Auth::user()->first_name); ?>" type="text" readonly=""></div>
                            </div>
                         </div>
                         <div class="form-group">
                            <label class="col-md-4 control-label">APELLIDOS DEL USUARIO:</label>
                            <div class="col-md-8 inputGroupContainer">
                               <div class="input-group"><span class="input-group-addon"><i class="glyphicon glyphicon-star-empty"></i></span><input id="last_name" name="last_name"  class="read form-control" value="<?php echo e(Auth::user()->last_name); ?>" type="text" readonly=""></div>
                            </div>
                         </div>
                         <div class="form-group">
                            <label class="col-md-4 control-label">EMAIL:</label>
                            <div class="col-md-8 inputGroupContainer">
                               <div class="input-group"><span class="input-group-addon"><i class="glyphicon glyphicon-envelope"></i></span><input id="email" name="email"  class="read form-control" value="<?php echo e(Auth::user()->email); ?>" type="text" readonly></div>
                            </div>
                         </div>
                         <div class="form-group">
                            <label class="col-md-4 control-label">Nº MÓVIL:</label>
                            <div class="col-md-8 inputGroupContainer">
                               <div class="input-group"><span class="input-group-addon"><i class="glyphicon glyphicon-phone"></i></span><input id="phone" name="phone" placeholder="phone" class="read form-control"  value="<?php echo e(Auth::user()->phone); ?>" type="text" readonly></div>
                            </div>
                         </div>
                         <div class="form-group">
                            <label class="col-md-4 control-label">ROLES DEL USUARIO:</label>
                            <div class="col-md-8 inputGroupContainer">
                              
                                <h4 align="center"><span class="label label-success" align=center>Roles Asignados</span></h4>
                                <?php $__currentLoopData = Auth::user()->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               
                                <?php echo e(Form::text('tmailz',$role->display_name , ['class' => 'roles read col-md-4 form-control input-md','readonly'])); ?>


                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         
                            </div>
                            </div>
                         </div>
                       
                
                      </fieldset>
                   </div>





</div>
 
  


  <div class="col-sm-3">
    

  </div>

</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('administrador.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>