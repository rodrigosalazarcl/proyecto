<?php ?>



@extends('administrador.index')

@section('headder')

<style type="text/css">

.intro { 
font-weight: bold;

}

.imgc {
    width: 100%;
    height: auto;
}

.invalid-feedback {
  display: block;
}
}
</style>


<nav aria-label="breadcrumb ">
 
  <ol class="breadcrumb arr-right bg-dark ">
 
    <li class="breadcrumb-item "><a href="#" class="text-light">Inicio</a></li>
 

    <li class="breadcrumb-item text-light" aria-current="page"><a href="{{ route('users.index') }}" class="text-light">Lista Usuarios</a></li>
 
    <li class="breadcrumb-item text-light active" aria-current="page">Crear Usuarios</li>
 

  </ol></nav>


@stop
@section('contenido')
@include('alert::bootstrap')
 <div class="container -body-block pb-5">
      
                    <a href="{{ url('backup/create') }}" class="nav-link text-primary" title="Crear nuevo backup">
                        <i class="far fa-plus" aria-hidden="true"></i> Crear nuevo backup
                    </a>
                </li>
        
    </div>
 @if (count($backups))

    <table class="table table-striped table-bordered">
        <thead class="thead-dark">
            <tr>
                <th>File</th>
                <th>Size</th>
                <th>Date</th>
                <th>Age</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            @foreach($backups as $backup)
                <tr>
                    <td>{{ $backup['file_name'] }}</td>
                    <td>{{ $backup['file_size'] }}</td>
                    <td>
                        {{ date('d/M/Y, g:ia', strtotime($backup['last_modified'])) }}
                    </td>
                    <td>
                   
                    </td>
                    <td class="text-right">
                        <a class="btn btn-primary" href="{{ url('backup/download/'.$backup['file_name']) }}">
                            <i class="fas fa-cloud-download"></i> Download</a>
                        <a class="btn btn-xs btn-danger" data-button-type="delete" href="{{ url('backup/delete/'.$backup['file_name']) }}">
                            <i class="fal fa-trash"></i>
                            Delete
                        </a>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
@else
    <div class="text-center py-5">
        <h1 class="text-muted">No existen backups</h1>
    </div>
@endif
@stop