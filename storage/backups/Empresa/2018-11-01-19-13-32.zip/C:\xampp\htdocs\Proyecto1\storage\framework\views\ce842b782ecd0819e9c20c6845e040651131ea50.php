<?php ?>





<?php $__env->startSection('headder'); ?>

<style type="text/css">

.intro { 
font-weight: bold;

}

.imgc {
    width: 100%;
    height: auto;
}

.invalid-feedback {
  display: block;
}
}
</style>


<nav aria-label="breadcrumb ">
 
  <ol class="breadcrumb arr-right bg-dark ">
 
    <li class="breadcrumb-item "><a href="#" class="text-light">Inicio</a></li>
 

    <li class="breadcrumb-item text-light" aria-current="page"><a href="<?php echo e(route('users.index')); ?>" class="text-light">Lista Usuarios</a></li>
 
    <li class="breadcrumb-item text-light active" aria-current="page">Crear Usuarios</li>
 

  </ol></nav>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenido'); ?>
<?php echo $__env->make('alert::bootstrap', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 <div class="container -body-block pb-5">
      
                    <a href="<?php echo e(url('backup/create')); ?>" class="nav-link text-primary" title="Crear nuevo backup">
                        <i class="far fa-plus" aria-hidden="true"></i> Crear nuevo backup
                    </a>
                </li>
        
    </div>
 <?php if(count($backups)): ?>

    <table class="table table-striped table-bordered">
        <thead class="thead-dark">
            <tr>
                <th>File</th>
                <th>Size</th>
                <th>Date</th>
                <th>Age</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $backups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $backup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($backup['file_name']); ?></td>
                    <td><?php echo e($backup['file_size']); ?></td>
                    <td>
                        <?php echo e(date('d/M/Y, g:ia', strtotime($backup['last_modified']))); ?>

                    </td>
                    <td>
                   
                    </td>
                    <td class="text-right">
                        <a class="btn btn-primary" href="<?php echo e(url('backup/download/'.$backup['file_name'])); ?>">
                            <i class="fas fa-cloud-download"></i> Download</a>
                        <a class="btn btn-xs btn-danger" data-button-type="delete" href="<?php echo e(url('backup/delete/'.$backup['file_name'])); ?>">
                            <i class="fal fa-trash"></i>
                            Delete
                        </a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php else: ?>
    <div class="text-center py-5">
        <h1 class="text-muted">No existen backups</h1>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('administrador.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>