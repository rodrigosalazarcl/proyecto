<?php ?>





<?php $__env->startSection('headder'); ?>

<div class="panel panel-warning ">
  <div class="panel-heading"><h5>Administración de Usuarios /Información de Usuario</h5></div>
  <div>
    <ol class="breadcrumb" style="background: white;">
  <li><a href="<?php echo e(url('seguridad')); ?>"><i class="fa fa-dashboard"></i> Inicio</a></li>
  <li><a href="<?php echo e(route('users.index')); ?>"><i class="fa fa-user"></i> Usuarios</a></li>
  <li class="active"><i class="fa fa-th"></i>Información</li>
</ol>
   
</div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenido'); ?>



    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-primary ">
                    <div class="panel-heading"><h4 align="center">Información de Usuario</h></div>

                    <div class="panel-body">


                        <div class="form-group">
                            <label for="name" class="col-md-4 control-label">Nombre</label>
                            <?php echo e($user->name); ?>

                        </div>


                        <div class="form-group">
                            <label for="name" class="col-md-4 control-label">E-mail</label>
                            <?php echo e($user->email); ?>

                        </div>


                        <div class="form-group">
                            <label for="name" class="col-md-4 control-label">Roles</label>
                            <?php if(!empty($user->roles)): ?>
                                <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <label class="label label-success"><?php echo e($role->display_name); ?></label>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                           <div class="form-group">
                                <div class="col-md-8 col-md-offset-4">
                                   
                                    <a class="btn btn-warning" href="<?php echo e(url('admin/users')); ?>">
                                        Cancel
                                    </a>
                                </div>
                            </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('administrador.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>