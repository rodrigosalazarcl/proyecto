<?php ?>





<?php $__env->startSection('headder'); ?>



<ol class="breadcrumb">
      <li><a href="<?php echo e(url('seguridad')); ?>"><i class="fa fa-dashboard"></i> Inicio</a></li>
  <li><a href="<?php echo e(route('users.index')); ?>"><i class="fa fa-user"></i> Usuarios</a></li>
  <li class="active"><i class="fa fa-th"></i>Eliminar Usuario</li>
</ol>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenido'); ?>

<style type="text/css">
    read-only {
  color: red !important;
}
    .read{ background: white !important;
     }


.blue{
    color:brown;
}
.red{
color: red;

}


.btn{
 white-space:normal !important;

  
}
.bn{

    margin: 15px;
    background-color: #EFEDF1;
    border: 1px solid #E2E3E8;
    padding: 10px;  
    word-break: break-all; 

}

</style>



    <div class="row ">
        <div class="panel panel-danger bn">
                    <div class="panel-heading" >
                     <h4 align="center" style=" font-style: italic;">Información de Usuario a Eliminar</h4></div>

                  </div>
        <div class="col-md-3">

 <div class="text-center">
       <br>
             <img src="<?php echo e(asset('img/jho.png')); ?>" class="avatar img-circle img-thumbnail" alt="User Image">


   <div class="panel panel-primary ">
                    <div class="panel-heading" >
              <h4 class="aju"><?php echo e($user->name); ?></h4>
                     <h5 align="center" style="display: inline-block font-style: italic;"><?php echo e($user->email); ?></h5>

             
                        <a class="btn btn-warning" style="display: inline-block" href="<?php echo e(url('admin/users')); ?>">
                                        Cancelar
                                    </a>
                                     <button  class="btn btn-danger glyphicon glyphicon-trash linea" data-toggle="modal" data-target="#myModal" title="eliminar">Eliminar</button>

                 </div>

                  </div>

      </div>



        </div>
        <div class="col-md-9">
            <div class="card">
                <div class="card-body" >
                    <div class="row">
                        <div class="col-md-10 col-md-offset-1">
                           <div class="alert alert-danger">
Información Perfil Usuario a Eliminar
</div>

                                    
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-10 col-md-offset-1">            

  
                 


            <div class="form-group row">
         <label class="col-md-4">Nombre Usuario</label>  
  <div class="col-md-8">
      <div class="input-group">
       <div class="input-group-addon">
     <i class=" fa fa-user blue"></i>
        
       </div>
        <?php echo e(Form::text('tname',$user->name, ['class' => 'red read col-md-4 form-control input-md','readonly'])); ?>

 
    </div>    
  </div>
</div>
     
       <div class="form-group row">
         <label class="col-md-4">Nombres del Usuario</label>  
  <div class="col-md-8">
      <div class="input-group">
       <div class="input-group-addon">
     <i class=" fa fa-user blue"></i>
        
       </div>
        <?php echo e(Form::text('tname',$user->first_name, ['class' => 'read col-md-4 form-control input-md','readonly'])); ?>

 
    </div>    
  </div>
</div>
       
         <div class="form-group row">
         <label class="col-md-4">Apellidos del Usuario</label>  
  <div class="col-md-8">
      <div class="input-group">
       <div class="input-group-addon">
     <i class=" fa fa-user blue"></i>
        
       </div>
        <?php echo e(Form::text('tname',$user->last_name, ['class' => 'read col-md-4 form-control input-md','readonly'])); ?>

 
    </div>    
  </div>
</div>
       


      <div class="form-group row">
         <label class="col-md-4">Email</label>  
  <div class="col-md-8">
      <div class="input-group">
       <div class="input-group-addon">
     <i class="fa fa-envelope fa blue"></i>
        
       </div>
             <?php echo e(Form::text('tmail',$user->email, ['class' => 'read col-md-4 form-control input-md','readonly'])); ?>

      </div>    
  </div>
</div>
      



        <div class="form-group row">
         <label class="col-md-4">Roles del Usuario</label>  
  <div class="col-md-8">
      <div class="input-group">
       <div class="input-group-addon">
     <i class="fa fa-group blue"></i>
        
       </div>                         <?php if(!empty($user->roles)): ?>
                                <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  
                                 <?php echo e(Form::text('tmailz',$role->display_name , ['class' => 'read col-md-4 form-control input-md','readonly'])); ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            
      </div>    
  </div>
</div>



        <div class="form-group row">
         <label class="col-md-4">Estado de Cuenta</label>  
  <div class="col-md-8">
      <div class="input-group">
       <div class="input-group-addon">
     <i class="fa fa-power-off blue"></i>
        
       </div>                    
            <?php if($user->status===0): ?>
                               
                 <?php echo e(Form::text('tstatus','Inactica', ['class' => 'read col-md-4 form-control input-md','readonly'])); ?>

                               
                            <?php endif; ?>

                             <?php if($user->status===1 ): ?>
                               
             <?php echo e(Form::text('tstatus','Activa', ['class' => 'read col-md-4 form-control input-md','readonly'])); ?>

                               
                            <?php endif; ?>
                            
                            
      </div>    
  </div>
</div>


      <div class="form-group row">
         <label class="col-md-4">Sexo</label>  
  <div class="col-md-8">
      <div class="input-group">
       <div class="input-group-addon">
     <i class="fa fa-asterisk blue"></i>
        
       </div>                         <?php if($user->gender==="m" ): ?>
                               
             <?php echo e(Form::text('Tsexo','Mujer', ['class' => 'read col-md-4 form-control input-md','readonly'])); ?>

                               
                            <?php endif; ?>

                             <?php if($user->gender==="h" ): ?>
                               
                    <?php echo e(Form::text('Tsexo','Hombre', ['class' => 'read col-md-4 form-control input-md','readonly'])); ?>

                               
                            <?php endif; ?>
                            
                            
      </div>    
  </div>
</div>


  <div class="form-group row">
         <label class="col-md-4">Nº móvil</label>  
  <div class="col-md-8">
      <div class="input-group">
       <div class="input-group-addon">
     <i class="fa fa-phone fa blue"></i>
        
       </div>
             <?php echo e(Form::text('tphone',$user->phone, ['class' => 'read col-md-4 form-control input-md','readonly'])); ?>

      </div>    
  </div>
</div>
      


  <div class="form-group row">
         <label class="col-md-4">Fecha Creación Usuario</label>  
  <div class="col-md-8">
      <div class="input-group">
       <div class="input-group-addon">
     <i class="fa fa-calendar blue"></i>
        
       </div>
             <?php echo e(Form::text('tcreacion',date_format($user->created_at, 'd/m/Y H:i:s'), ['class' => 'read col-md-4 form-control input-md','readonly'])); ?>

      </div>    
  </div>
</div>


  <div class="form-group row">
         <label class="col-md-4">Fecha última Actualización de datos</label>  
  <div class="col-md-8">
      <div class="input-group">
       <div class="input-group-addon">
     <i class="fa fa-calendar blue"></i>
        
       </div>
             <?php echo e(Form::text('tcreacion',date_format($user->updated_at, 'd/m/Y H:i:s'), ['class' => 'read col-md-4 form-control input-md','readonly'])); ?>

      </div>    
  </div>
</div>





                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>                                          









<div class="modal modal-danger fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title text-center" id="myModalLabel">Confirmar Eliminación usuario</h4>
      </div>
     <form class="w3-container" action="<?php echo e(url('admin/users/'.$user->id)); ?>" method="POST">
          <?php echo e(method_field('delete')); ?>

          <?php echo e(csrf_field()); ?>

        <div class="modal-body">
        <p class="text-center">
        Estás seguro de eliminar al usuario: <span class="badge" style="color:black;background-color:white; "><?php echo e($user->name); ?></span></button>
        </p>
            <input type="hidden" name="category_id" id="cat_id" value="">

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-success" data-dismiss="modal">No, Cancelar</button>
          <button type="submit" class="btn btn-warning">Sí, Eliminar</button>
        </div>
      </form>
    </div>
  </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('administrador.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>