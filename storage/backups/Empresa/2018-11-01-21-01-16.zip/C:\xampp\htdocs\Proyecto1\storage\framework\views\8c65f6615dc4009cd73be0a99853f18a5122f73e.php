<?php ?>





<?php $__env->startSection('headder'); ?>


     
   
<nav aria-label="breadcrumb ">
 
  <ol class="breadcrumb arr-right bg-dark ">
 
    <li class="breadcrumb-item "><a href="#" class="text-light">Inicio</a></li>
 

    <li class="breadcrumb-item text-light" aria-current="page"><a href="<?php echo e(route('roles.index')); ?>" class="text-light">Lista Roles</a></li>
 
    <li class="breadcrumb-item text-light active" aria-current="page">Crear Roles</li>
 

  </ol></nav>


<?php $__env->stopSection(); ?>


<style type="text/css">
    .red{
    color: red;
}

</style>




<?php $__env->startSection('contenido'); ?>


 <div class="container-fluid">
  <div class="row">

<div class="col-md-1 responsive">
</div>
<div class="col-md-8 responsive">
    <div class="card">
  <h5 class="card-header">Admninistración de roles</h5>
  <div class="card-body">


    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/hover.css/2.3.1/css/hover-min.css">
    

        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-primary">
                    <div class="panel-heading"><h4 align="center">Crear nuevo Rol Administrativo</h4></div>

                    <div class="panel-body">
                        <!-- Display Validation Errors -->
                        <?php if(count($errors) > 0): ?>
                            <div class="alert alert-danger">
                                <strong>Problemas!</strong> Algunos campos no están correctos <br><br>
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('admin/roles/store')); ?>">
                            <?php echo e(csrf_field()); ?>


                           






 <label class="control-label">Nombre de Rol :</label>
<div class="input-group mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text"><i class="fa fa-user-circle-o"></i></span>
  </div>
  <input class="form-control form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?> " type="text" name="name" placeholder="ingrese nombre del rol" maxlength="100" value="<?php echo e(old('name')); ?>" required>
      <?php if($errors->has('name')): ?>
                                    <div class="invalid-feedback">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </div>
                                <?php endif; ?>
</div>




 <label class="control-label">Nombre a desplegar :</label>
<div class="input-group mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text"><i class="fa  fa-user-circle-o"></i></span>
  </div>
  <input class="form-control form-control<?php echo e($errors->has('display_name') ? ' is-invalid' : ''); ?> " type="text" name="display_name" placeholder="ingrese nombre del rol" maxlength="70" value="<?php echo e(old('display_name')); ?>" required>
      <?php if($errors->has('display_name')): ?>
                                    <div class="invalid-feedback">
                                        <strong><?php echo e($errors->first('display_name')); ?></strong>
                                    </div>
                                <?php endif; ?>
</div>



 <label class="control-label">Descripción  del Rol :</label>
<div class="input-group mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text"><i class="fa  fa fa-user-circle-o"></i></span>
  </div>
 
   
<?php echo e(Form::textarea('description',Input::old('description'),['class' => ($errors->has('description')) ? 'form-control is-invalid' : 'form-control','required','rows' => 4, 'cols' => 50, 'placeholder' => 'ingrese descripción del rol'])); ?>


</div>
   <?php if($errors->has('description')): ?>
                                    <div class="invalid-feedback">
                                        <strong><?php echo e($errors->first('description')); ?></strong>
                                    </div>
                                <?php endif; ?>






                        
                     <div class="form-control form-control<?php echo e($errors->has('permissions') ? ' is-invalid' : ''); ?>" style="background:#EFFBF5;"

                                <div class="">
                                   

   <h5><b>Asignar Permisos:</b></h5>
    <div class='form-group'>
        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e(Form::checkbox('permissions[]',  $permission->id )); ?>

            <b style="color: red;"><?php echo e($permission->display_name); ?></b> (<?php echo e(($permission->description)); ?>)<hr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>





                                    <?php if($errors->has('permissions')): ?>
                                    <br>
                                    <br>
                                        <span style="color: red;">
                                        <strong><?php echo e($errors->first('permissions')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
</div>



                            <div class="form-group">
                                <div class="col-md-8 col-md-offset-4">
                                    <button type="submit" class="btn btn-primary">
                                       Guardar
                                    </button>

                                    <a class="btn btn-warning" href="<?php echo e(url('admin/roles')); ?>">
                                        Cancelar
                                    </a>
                                </div>
                            </div>
                            
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>





</div>
</div>
</div>
<div class="col-md-3 responsive">
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('administrador.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>