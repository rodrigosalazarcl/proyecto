<?php $__env->startSection('title', 'PAGINA EXPIRADA'); ?>

<?php $__env->startSection('message'); ?>
  La página ha expirado por inactividad
    <br/><br/>
    Por favor refresca e intenta nuevamente
<?php $__env->stopSection(); ?>

<?php echo $__env->make('errors::layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>