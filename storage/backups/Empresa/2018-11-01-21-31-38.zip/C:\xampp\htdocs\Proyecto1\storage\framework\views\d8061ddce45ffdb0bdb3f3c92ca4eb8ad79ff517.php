<?php ?>





<?php $__env->startSection('headder'); ?>

<div class="panel panel-warning ">
  <div class="panel-heading"><h5>Administración de Usuarios / Crear Usuario</h5></div>
  <div>
    <ol class="breadcrumb" style="background: white;">
  <li><a href="<?php echo e(url('seguridad')); ?>"><i class="fa fa-dashboard"></i> Inicio</a></li>
  <li><a href="<?php echo e(route('users.index')); ?>"><i class="fa fa-user"></i> Usuarios</a></li>
  <li class="active"><i class="fa fa-th"></i>Crear</li>
</ol>
   
</div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenido'); ?>



    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-primary ">
                    <div class="panel-heading"><h4 align="center">Crear Usuario</h></div>

                    <div class="panel-body">
                        <!-- Display Validation Errors -->
                        <?php if(count($errors) > 0): ?>
                            <div class="alert alert-danger">
                                <strong>Whoops!</strong> Problemas al ingressar datos.<br><br>
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>


     <?php echo Form::open(['route'=>'users.store','method'=>'POST']); ?>




<div class="form-group">
    <?php echo Form::label('name', 'Nombre Usuario'); ?>

    <?php echo Form::text('name', null, ['class' => 'form-control awesome']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('email', 'Dirección Email'); ?>

    <?php echo Form::text('email', null, ['class' => 'form-control awesome']); ?>

</div>

<div class="form-group">
     <?php echo Form::label('contraseña', 'contraseña'); ?>

   <?php echo e(Form::password('password', ['class' => 'form-control awesome'])); ?>

</div>

<div class="form-group">
     <?php echo Form::label('Passwordmm', 'pasword'); ?>

   <?php echo e(Form::password('password_confirmation', ['class' => 'form-control awesome'])); ?>

</div>




<div class="form-group">
   
  <div class="form-group<?php echo e($errors->has('roles') ? ' has-error' : ''); ?>">
                                <label for="roles" class="col-md-4 control-label">Roles</label>

                                <div class="col-md-6">
                                    <select id="role" name="roles[]" multiple>
                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>"><?php echo e($role); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>


                                    <?php if($errors->has('roles')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('roles')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
</div>


<?php echo Form::submit('Submit', ['class' => 'btn btn-info']); ?>


<?php echo Form::close(); ?>



                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('administrador.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>