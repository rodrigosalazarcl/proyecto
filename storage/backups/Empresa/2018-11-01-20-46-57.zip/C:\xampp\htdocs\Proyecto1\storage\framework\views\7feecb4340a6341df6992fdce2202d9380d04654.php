<?php ?>

<?php ?>





<?php $__env->startSection('headder'); ?>




<ol class="breadcrumb">
      <li><a href="<?php echo e(url('seguridad')); ?>"><i class="fa fa-dashboard"></i> Inicio</a></li>
  <li><a href="<?php echo e(route('users.index')); ?>"><i class="fa fa-user"></i> Usuarios</a></li>
  <li class="active"><i class="fa fa-th"></i>Editar Usuario</li>
</ol>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenido'); ?>



    <div class="container">
        <div class="row">
          <div class="col-md-1">
            <img src="<?php echo e(asset('img/edit-user.png')); ?>" width="200px" class="user-image" alt="User Image">
          </div>

  <div class="col-md-7  col-md-offset-2">

                <div class="panel panel-primary ">
                    <div class="panel-heading">
                     <h4 align="center">Editar Usuario</h4></div>

                    <div class="panel-body">
                        <!-- Display Validation Errors -->
                        <?php if(count($errors) > 0): ?>
                            <div class="alert alert-danger">
                                <strong>Whoops!</strong> Problemas al ingresar datos.<br><br>
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>


      <?php echo Form::model($user,['route'=>['users.update',$user->id],'method'=>'patch']); ?>


  <?php echo e(csrf_field()); ?>



  <div class="form-group">
     <div class="form-group <?php echo e($errors->has('name') ? 'has-error' :''); ?>">
             <?php echo e(Form::label('lname', 'Nombre User', ['class' => 'control-label'])); ?>

              <div class="cols-sm-10">
                <div class="input-group">
                  <span class="input-group-addon"><i class="fa fa-user fa" aria-hidden="true"></i></span>
                 <?php echo e(Form::text('name', $user->name, ['class' => 'form-control awesome','maxlength' => 30,'placeholder'=>'ingrese nombre usuario','required' => 'required'])); ?>

                </div>
              </div>
            </div>
</div>


  <div class="form-group">
     <div class="form-group <?php echo e($errors->has('first_name') ? 'has-error' :''); ?>">
             <?php echo e(Form::label('lfirstname', 'Nombres de Usuario', ['class' => 'control-label'])); ?>

              <div class="cols-sm-10">
                <div class="input-group">
                  <span class="input-group-addon"><i class="fa fa-user fa" aria-hidden="true"></i></span>
                 <?php echo e(Form::text('first_name', $user->first_name, ['class' => 'form-control awesome','maxlength' => 120,'placeholder'=>'ingrese nombre usuario','required' => 'required'])); ?>

                </div>
              </div>
            </div>
</div>

  <div class="form-group">
     <div class="form-group <?php echo e($errors->has('last_name') ? 'has-error' :''); ?>">
             <?php echo e(Form::label('llastname', 'Apellidos de Usuario', ['class' => 'control-label'])); ?>

              <div class="cols-sm-10">
                <div class="input-group">
                  <span class="input-group-addon"><i class="fa fa-user fa" aria-hidden="true"></i></span>
                 <?php echo e(Form::text('last_name', $user->last_name, ['class' => 'form-control awesome','maxlength' => 120,'placeholder'=>'ingrese nombre usuario','required' => 'required'])); ?>

                </div>
              </div>
            </div>
</div>

    <div class="form-group">
      <div class="form-group <?php echo e($errors->has('email') ? 'has-error' :''); ?>">
              <?php echo e(Form::label('lemail', 'Dirección Email')); ?>

              <div class="cols-sm-10">
                <div class="input-group">
                  <span class="input-group-addon"><i class="fa fa-envelope fa" aria-hidden="true"></i></span>
                 <?php echo e(Form::text('email', $user->email, ['class' => 'form-control awesome','maxlength' => 191, 'placeholder'=>'ingrese correo','required' => 'required'])); ?>

                </div>
              </div>
            </div>
</div>

 



  <div class="form-group">
      <div class="form-group <?php echo e($errors->has('phone') ? 'has-error' :''); ?>">
                   <?php echo e(Form::label('lphone', 'Nº móvil', ['class' => 'control-label'])); ?>

              <div class="cols-sm-10">
                <div class="input-group">
                  <span class="input-group-addon"><i class="fa fa-phone fa-lg" aria-hidden="true"></i></span>
                  <?php echo e(Form::text('phone', $user->phone, array('placeholder' => '','maxlength' =>9,'class' => 'form-control awesome','placeholder'=>'ingrese teléfono','required' => 'required'))); ?>

                </div>
              
              </div>
            </div>
          </div>


                         
                             

                                <div class="form-group">
       <div class="form-group<?php echo e($errors->has('roles') ? ' has-error' : ''); ?>">
    <?php echo e(Form::label('lrol', 'Roles')); ?>

       <div class="cols-sm-10">
        <div class="input-group">
           <span class="input-group-addon"><i class="fa fa-user
 fa-lg" aria-hidden="true"></i></span>
      <select id="role" name="roles[]" class="form-control awesome" multiple>
                                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($role->id); ?>" <?php echo e(in_array($role->id, $userRoles) ? "selected" : null); ?>>
                                                <?php echo e($role->display_name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                                    <?php if($errors->has('roles')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('roles')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
</div></div>

   
     <div class="form-group">
    <div class="form-group <?php echo e($errors->has('gender') ? 'has-error' :''); ?>">
       <?php echo e(Form::label('lsexo', 'Sexo')); ?>

              <div class="cols-sm-10">
                <div class="input-group">
                  <span class="input-group-addon"><i class="fa fa-genderless
 fa-lg" aria-hidden="true"></i></span>
                
     <?php echo e(Form::select('gender', ['0'=>'elige un sexo','m' => 'mujer', 'h' => 'hombre'], $user->gender, ['class' => 'form-control awesome','required'])); ?>

                </div>
              
              </div>
            </div>
          </div>



    <div class="form-group">
   
    <div class="form-group <?php echo e($errors->has('status') ? 'has-error' :''); ?>">
      <?php echo e(Form::label('lEstado', 'Estado cuenta ususaria')); ?>

              <div class="cols-sm-10">
                <div class="input-group">
                  <span class="input-group-addon"><i class="fa fa-check
 fa-lg" aria-hidden="true"></i></span>
                


     <?php echo e(Form::select('status', ['9' => 'selecciona un estado de cuenta','0' => 'Inactiva','1' => 'Activo'],$user->status, ['class' => 'form-control awesome'])); ?>

                </div>
              
              </div>
            </div>
          </div>



<div class="card alert alert-danger" align="center"">
  <div align="center" class="card-body">
    <h5 class="card-title">Cambio de Contraseña</h5>
    <h6 class="card-subtitle mb-2">Cuidado</h6>
    <p class="card-text">Puedes cambiarle la contraseña al usuario</p>

  </div>
</div>



 <div class="form-group">
      <div class="form-group <?php echo e($errors->has('password') ? 'has-error' :''); ?>">
              <?php echo e(Form::label('lcontraseña', 'contraseña')); ?>

              <div class="cols-sm-10">
                <div class="input-group">
                  <span class="input-group-addon"><i class="fa fa-lock fa-lg" aria-hidden="true"></i></span>
                    <?php echo e(Form::password('password', ['class' => 'form-control awesome','maxlength' => 128,'placeholder'=>'ingrese contraseña'])); ?>

                </div>
              
              </div>
            </div>
          </div>


  <div class="form-group">
      <div class="form-group <?php echo e($errors->has('password_confirmation') ? 'has-error' :''); ?>">
                <?php echo e(Form::label('lPasswordmm', 'confirmar contraseña')); ?>

              <div class="cols-sm-10">
                <div class="input-group">
                  <span class="input-group-addon"><i class="fa fa-lock fa-lg" aria-hidden="true"></i></span>
                  <?php echo e(Form::password('password_confirmation', ['class' => 'form-control awesome','maxlength' => 128,'placeholder'=>'confirme contraseña'])); ?>

                </div>
              
              </div>
            </div>
          </div>





<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
 <div class="modal-dialog modal-notify modal-warning" role="document">
    <div class="modal-content">
      <div class="modal-header">
           <h3 class="modal-title">Estas seguro de Guardar los cambios</h3>
         <form class="w3-container"  onKeypress="if(event.keyCode == 13) event.returnValue = false;">
            
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel"><i class="glyphicon glyphicon-erase"></i>

          <span id="nombre" style="font-family: sans-serif; color:black"></span>
             (se guardaran los cambios de la cuenta del usuario)

          

    
      <div class="modal-footer">
         <?php echo e(Form::submit('Guardar', ['class' => 'btn btn-info'])); ?>

        <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
      
    </div>
        </form>
         </div>
      </div>

    </div>
  </div>




<button class="btn btn-success glyphicon" data-toggle="modal" data-target="#myModal" title="guardar">Guardar  Cambios</button>

                                    <a class="btn btn-warning" href="<?php echo e(url('admin/users')); ?>">
                                        Cancelar
                                    </a>
<?php echo e(Form::close()); ?>

</div>















                    </div>
                </div>
           
        </div>
          
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('administrador.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>