<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>PLATAFORMA WEB | <?php echo e(Auth::user()->email); ?></title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
    <!-- Bootstrap-select 1.12.4 -->
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-select.css')); ?>">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(asset('css/font-awesome.css')); ?>">
    <!-- Theme style -->
    <!-- AdminLTE Skins. Choose a skin from the css/skins
        folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="<?php echo e(asset('css/AdminLTE.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('css/plusis.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/_all-skins.css')); ?>">
    
    <link rel="shortcut icon" href="<?php echo e(asset('img/jho.png')); ?>">
  </head>
    

   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/hover.css/2.3.1/css/hover-min.css">



<style type="text/css">
  
.breadcrumb {background: rgba(14, 117, 158, 1); border: 10px solid rgba(245, 245, 245, 1); border-radius: 25px; display: block;}
.breadcrumb li {font-size: 15px;}
.breadcrumb a {color: rgba(217, 226, 235, 1);}
.breadcrumb a:hover {color: rgba(231, 236, 240, 0.87);}
.breadcrumb>.active {color: rgba(247, 242, 242, 1);}
.breadcrumb>li+li:before {color: rgba(204, 204, 204, 1); content: "\2771\00a0";}


</style>




  <body class="hold-transition skin-blue sidebar-mini">
    <div style="display: none;" id="cargador_empresa" align="center"><br>
      <center><label style="color:#FFF; background-color:#ABB6BA; text-align:center">&nbsp;&nbsp;&nbsp;Espere... &nbsp;&nbsp;&nbsp;</label><br>
      <label style="color:#ABB6BA">Realizando tarea solicitada ...</label><br></center>
      <center style="margin-top: 10px">
        <img src="<?php echo e(url('/img/cargando.gif')); ?>" align="middle" alt="cargador"> 
      </center>
      <hr style="color:#003" width="50%"><br>
    </div>
    <input type="hidden"  id="url_raiz_proyecto" value="<?php echo e(url('/')); ?>" />
    <div id="capa_modal" class="div_modal" style="display: none;"></div>
    <div id="capa_formularios" class="div_contenido" style="display: none;"></div>
    
    <div class="wrapper">
      <header class="main-header">
        <!-- Logo -->
        <a href="index2.html" class="logo">
          <!-- mini logo for sidebar mini 50x50 pixels -->
          <span class="logo-mini"><b>PLATAFORMA WEB</b>y</span>
          <!-- logo for regular state and mobile devices -->
          <span class="logo-lg"><b>PLATAFORMA WEB</b></span>
        </a>
        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top" role="navigation">
          <!-- Sidebar toggle button-->
          <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Navegación</span>
          </a>
          <!-- Navbar Right Menu -->
          <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
              <!-- Messages: style can be found in dropdown.less--> 
              

                   


              <li class="dropdown">
               
              </li>
              <!-- User Account: style can be found in dropdown.less -->
              <li class="dropdown user user-menu responsive">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">

                  <?php if(Auth::user()->gender==='h'): ?>
                     <img src="<?php echo e(asset('img/hombre1.png')); ?>" class="user-image" alt="User Image">
                  <?php endif; ?>
                  <?php if(Auth::user()->gender==='m'): ?>
                     <img src="<?php echo e(asset('img/mujer1.jpg')); ?>" class="user-image" alt="User Image">
                  <?php endif; ?>
                 
                  <span class="hidden-xs"><?php echo e(Auth::user()->email); ?></span>
                </a>
                <ul class="dropdown-menu">
                  <!-- User image -->
                  <li class="user-header"> 

                  <?php if(Auth::user()->gender==='h'): ?>
                    <img src="<?php echo e(asset('img/hombre1.png')); ?>" class="img-circle" alt="User Image">
                    <?php endif; ?>

                  <?php if(Auth::user()->gender==='m'): ?>
                    <img src="<?php echo e(asset('img/mujer1.jpg')); ?>" class="img-circle" alt="User Image">
                    <?php endif; ?>
                    <p>
                      <?php echo e(Auth::user()->name); ?>

                      <small> <?php echo e(Auth::user()->email); ?></small>
                    </p>
                  </li>
                  
                  <!-- Menu Footer-->
                  <li class="user-footer">
                    <div class="pull-left">
                     <a href="<?php echo e(route('profile')); ?>" style="color:white;" class="btn btn-default btn-info" value="<?php echo e(Auth::user()->id); ?>">Mi perfil</a>
                    </div>
                    <div class="pull-right">
                      <a href="<?php echo e(route('logout')); ?>" style="color:white;" class="btn btn-default btn-info"  onclick="event.preventDefault();
                          document.getElementById('logout-form').submit();">Salir</a>
                      <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo e(csrf_field()); ?>

                      </form>
                    </div>
                  </li>
                </ul>
              </li>
            </ul>
          </div>
        </nav>
      </header>

      <!-- Left side column. contains the logo and sidebar -->
      <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
          <!-- Sidebar user panel -->        
          <!-- sidebar menu: : style can be found in sidebar.less -->
          <ul class="sidebar-menu">
            <li class="header"></li>
       
            

            <li class="sidebar-menu-left">
              <a href="#">
                <i class="fa fa-folder"></i> <span>Administración</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">


<?php if (\Entrust::can(['user-update','user-delete','user-list','user-create'])) : ?>
                <li><a href="<?php echo e(route('users.index')); ?>"><i  class="fa fa-user"></i> Usuarios</a></li>

                <?php endif; // Entrust::can ?>



<?php if (\Entrust::can(['role-update','role-delete','role-list','role-create'])) : ?>
                <li><a href="<?php echo e(route('roles.index')); ?>"><i class="fa fa-cog"></i> Roles</a></li>
              
 <?php endif; // Entrust::can ?>


              </ul>
            </li>
          




   <li class="sidebar-menu-left">
              <a href="#">
                <i class="fa fa-folder"></i> <span>Logs</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">


<?php if (\Entrust::can(['user-update','user-delete','user-list','user-create'])) : ?>
                <li><a href="<?php echo e(route('logs.index')); ?>"><i  class="fa fa-user"></i>Ver logs de usuarios</a></li>
              
 <?php endif; // Entrust::can ?>
              </ul>
            </li>











             <li>
              <a href="#">
                <i class="fa fa-plus-square"></i> <span>Ayuda</span>
                <small class="label pull-right bg-red">PDF</small>
              </a>
            </li>

            <li>
              <a href="<?php echo e(url('programadores')); ?>">
                <i class="fa fa-info-circle"></i><span>Acerca De...</span>
                <small class="label pull-right bg-yellow">IT</small>
              </a>
            </li>           
          </ul>
        </section>
        <!-- /.sidebar -->
      </aside>

       <!--Contenido-->
      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper" style="background: white;">
        <!-- Content Header (Page header) -->
      

           <?php echo $__env->yieldContent('headder'); ?>
     
        <!-- Main content -->
        <section class="content">

          <?php echo $__env->yieldContent('contenido'); ?>

        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
      <!--Fin-Contenido-->
      <footer class="main-footer">
        <div class="pull-right hidden-xs">
          <b>Version</b> 1.0.0
        </div>
        <strong>Copyright &copy; <?php echo(date('Y',time())) ?>
          <a href=""> Rodrigo Salazar</a>
        </strong>todos los derechos reservados.
      </footer>

    <!-- jQuery 2.1.4 -->
    <script src="<?php echo e(asset('js/jQuery-2.1.4.min.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('script'); ?>
    <!-- Bootstrap 3.3.5 -->
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <!-- Bootstrap-select 1.12.4 -->

    <?php echo $__env->yieldPushContent('char'); ?>
    <!-- AdminLTE App -->
    <script src="<?php echo e(asset('js/app.min.js')); ?>"></script>
   
    <?php echo $__env->yieldPushContent('chart'); ?>
    <script src="<?php echo e(asset('js/plusis.js')); ?>"></script>


  
  </body>
</html>