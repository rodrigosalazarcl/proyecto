<?php ?>





<?php $__env->startSection('headder'); ?>


    <ol class="breadcrumb">
  <li><a><i class="fa fa-dashboard"></i> Inicio</a></li>
  <li class="active"><i class="fa fa-th"></i>Usuarios</li>
  
</ol>
   

<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenido'); ?>


    <style type="text/css">
tr:nth-child(even) {background-color: #f2f2f2;}
    table{text-align: center;
      font-size: 12px;}
 th {

color: white;
border: black 1px solid;
   text-align: center;
   background-color:#12bbad;
    }
}
 table, td {
	
border: orange 5px solid;
   text-align: left;
   border:1px solid black;

}

</style>



<?php if (\Entrust::can('user-create')) : ?>
<a href="<?php echo e(route('users.create')); ?>"><button class="btn btn-success">  Nuevo Usuario</button></a> 

<br/>
<br/>
    <?php endif; // Entrust::can ?>
<?php echo $__env->make('datatable.general.script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div style="overflow-x:auto;"  align="center" margin="0 auto" >

<?php echo e($dataTable->table(['class' => 'table-responsive warning grocery-crud-table cell-border table-hover compact dataTable_width_auto table-striped', 'id' => 'table'])); ?>

</div>

<?php echo $dataTable->scripts(); ?>


<?php echo $__env->make('flashy::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('administrador.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>